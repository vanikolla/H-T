import java.sql.*;
import java.util.Scanner;

public class Delete {


    static final String d_Url = "jdbc:mysql://localhost:3306/demo";
    static final String User = "root";
    static final String pwd = "pass@word1";
    static final String query2 = "Delete from  demo where id = ?;";

    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(d_Url, User, pwd);
            PreparedStatement prep = conn.prepareStatement(query2);
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter which need to delete:");
            int id = sc.nextInt();

            prep.setInt(1, id);
            prep.executeUpdate();
        } catch (Exception e) {

        }

    }
}