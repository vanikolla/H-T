import java.sql.*;
import java.util.Scanner;

public class Insert {

    static final String d_Url = "jdbc:mysql://localhost:3306/demo";
    static final String User = "root";
    static final String pwd = "pass@word1";
    static final String query2 = "insert into demo (id,f_name,l_name,address,city) values (?,?,?,?,?);";

    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(d_Url, User, pwd);

            PreparedStatement prep = conn.prepareStatement(query2);
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter id:");
            int id = sc.nextInt();
            System.out.println("Enter f_name:");
            String s1 = sc.next();
            System.out.println("Enter n_name:");
            String s2 = sc.next();
            System.out.println("Enter address:");
            String s3 = sc.next();
            System.out.println("Enter city:");
            String s4 = sc.next();

            prep.setInt(1, id);
            prep.setString(2, s1);
            prep.setString(3, s2);
            prep.setString(4, s3);
            prep.setString(5, s4);
            prep.executeUpdate();
System.out.println(User);
        } catch (Exception e) {
        }
    }
}
