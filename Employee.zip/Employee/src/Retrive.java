import java.sql.*;
public class Retrive {
    static final String d_Url = "jdbc:mysql://localhost:3306/democog";
    static final String User = "root";
    static final String pwd = "pass@word1";
    static final String query = "select * from democog";

    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(d_Url, User, pwd);
             Statement stat = con.createStatement();
             ResultSet rs = stat.executeQuery(query);) {

            while (rs.next()) {
                System.out.println("Employee ID"+ rs.getInt("id"));
                System.out.println("Employee ID"+ rs.getString("f_name"));
                System.out.println("Employee ID"+ rs.getString("l_name"));
            }

        } catch (SQLException e) {

        }




    }
}
