
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;

public class RetriveWithId {
    static final String d_Url = "jdbc:mysql://localhost:3306/democog";
    static final String User = "root";
    static final String pwd = "pass@word1";
    static final String query2 = "select * from demo where id = ?;";

    public static void main(String[] args) {
        try{
            Connection con = DriverManager.getConnection(d_Url, User, pwd);
            Statement stat = con.createStatement();
            PreparedStatement prep= con.prepareStatement(query2);
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter id:");
            int id = sc.nextInt();

            prep.setInt(1, id);
            ResultSet rs = prep.executeQuery();
            while (rs.next() ){
                System.out.println("id : " + rs.getInt("id") + " name : " + rs.getString("f_name") + " " + rs.getString("l_naame"));
            }
        } catch (Exception e) {
        }

    }
}