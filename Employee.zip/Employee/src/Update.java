import java.sql.*;
import java.util.Scanner;

public class Update {

    static final String d_Url = "jdbc:mysql::/localhost:3306/democog";
    static final String User = "root";
    static final String pwd = "pass@word1";
    static final String query2 = "Update demo set address = ? where id = ? ;";

    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(d_Url, User, pwd);
            Statement stat = conn.createStatement();
            PreparedStatement prep = conn.prepareStatement(query2);
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter id which need to Update:");
            int id = sc.nextInt();
           // System.out.println("Select Field which has to be Update f_name,l_name,address,city");
           // String s1 = sc.next();
            System.out.println("Enter Adress :");
            String s2 = sc.next();
            prep.setInt(2,id);
           // prep.setString(1,s1);
            prep.setString(1, s2);
            prep.executeUpdate();
        }
        catch (Exception e) {
        }
    }
}