import java.sql.*;

public class DBConnection {
    Connection con = null;
    public static Connection connectDB() {

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tweetapp",
                    "root", "pass@word1");
            return con;
        } catch (SQLException e) {

            System.out.println(e);
        }
        return null;
    }
}
