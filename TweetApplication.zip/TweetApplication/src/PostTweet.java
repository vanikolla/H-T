import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class PostTweet {
    static final String query = "insert into tweets (email,tweet) values(?,?);";
    public static void postTweet(String email){
        try{
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter Tweet:");
            String tweet = in.nextLine();

            prep.setString(1,email);
            prep.setString(2,tweet);
            prep.executeUpdate();


        }catch (Exception e){
            System.out.println(e);
        }
    }
}
