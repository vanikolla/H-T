import java.sql.*;
import java.util.Scanner;

public class Registration {
    static final String query = "insert into registration (first_name,email,password) values(?,?,?);";
    public static void register(){
        try{
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter first_name:");
            String name = in.nextLine();
            System.out.println("Enter email:");
            String email = in.next();
            System.out.println("Enter password:");
            String password = in.next();

            prep.setString(1,name);
            prep.setString(2,email);
            prep.setString(3,password);
            prep.executeUpdate();


        }catch (Exception e){
            System.out.println(e);
        }
    }
}
