import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class UpdateActveStatus {
    static final String query = "update tweetapp.registration set active = ? where email = ?;";
    public static void updateStatus(String email,String status){
        try {
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1,status);
            prep.setString(2, email);
            prep.executeUpdate();
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
