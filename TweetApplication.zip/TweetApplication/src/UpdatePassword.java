import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class UpdatePassword {
    static final String query = "update tweetapp.registration set password = ? where email = ?;";
    public static void updatePassword(String email){
        try {
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter new password:");
            String password = in.next();
            prep.setString(1,password);
            prep.setString(2, email);
            prep.executeUpdate();
        }catch (Exception e){
            System.out.println(e);
        }
    }

    static final String query1 = "select * from tweetapp.registration where email = ?;";
    public static void forgotPassword(){
        try {
            Connection conn = DBConnection.connectDB();
            PreparedStatement prep = conn.prepareStatement(query1);
            Scanner in = new Scanner(System.in);
            System.out.println("Enter email:");
            String email = in.next();
            prep.setString(1, email);
            ResultSet rs = prep.executeQuery();
            if (rs.next()){
                prep = conn.prepareStatement(query);
                System.out.println("Enter new password:");
                String password = in.next();
                prep.setString(1,password);
                prep.setString(2, email);
                prep.executeUpdate();
            }else {
                System.out.println("Invalid user");
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
