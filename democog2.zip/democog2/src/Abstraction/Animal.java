package Abstraction;

abstract class bike{
    abstract void run();
}
class honda extends bike{
    public void run(){
        System.out.println("honda bike is running");
    }
}

public class Animal {

    public static void main(String[] args){

        honda h= new honda();
        h.run();

    }
}
