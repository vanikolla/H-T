package Encapsulation;

public class Student {

    private String sname;
    private String stdid;
    private int age;
    private String collegename;

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getStdid() {
        return stdid;
    }

    public void setStdid(String stdid) {
        this.stdid = stdid;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCollegename() {
        return collegename;
    }

    public void setCollegename(String collegename) {
        this.collegename = collegename;
    }
}
 class test1 {
    public static void main(String[] args) {

        Student s = new Student();
        s.setAge(23);
        s.setCollegename("sv collge");
        s.setStdid("C-12345");
        s.setSname("vani");

        System.out.println(s.getAge() + " " + s.getCollegename() + " " + s.getSname() + " " + s.getStdid());

    }
}
