package Inheritance;

public class Animal {
    void sleeping(){
        System.out.println("Animal is sleeping");
    }
}
