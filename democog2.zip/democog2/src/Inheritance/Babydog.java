package Inheritance;

public class Babydog extends Dog {
    void playing() {
        System.out.println("babydog is playing");
    }
}