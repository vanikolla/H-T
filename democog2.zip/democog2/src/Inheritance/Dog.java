package Inheritance;

public class Dog extends Animal {
    void barking() {
        System.out.println("Dog is barking");
    }
}