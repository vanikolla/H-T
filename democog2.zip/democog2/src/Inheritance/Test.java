package Inheritance;

public class Test {
    public static void main(String[] args){
        Babydog b =new Babydog();
        b.playing();
        b.barking();
        b.sleeping();
    }
}
