package LamdaExpression;

import java.util.ArrayList;
import java.util.List;

public class demo {
    public static void main(String[] args){

        List<String>list=new ArrayList<String>();

        list.add("vani");
        list.add("kolla");
        list.add("nilu");
        list.add("siri");
        list.add("mani");

        list.forEach(
                (n)->System.out.println(n)
        );
    }
}
