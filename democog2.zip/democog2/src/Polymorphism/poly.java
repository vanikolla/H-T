package Polymorphism;

class Employee{
    void status(){
        System.out.println("Employee status");
    }
}
class COG extends Employee {
    void status() {
        System.out.println("COG status");
    }
}
class ACE extends Employee{
    void status(){
        System.out.println("ACE status");
    }
}

public class poly {

    public static void main(String[] args){
        Employee c=new Employee();
        Employee b=new COG();
        Employee a=new ACE();
        c.status();
        b.status();
        a.status();
    }
}
