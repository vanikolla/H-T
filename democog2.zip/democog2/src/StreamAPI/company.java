package StreamAPI;

import java.util.ArrayList;
import java.util.List;

class Product{
    int id;
    String name;
    float price;
    public Product(int id,String name,float price){
        this.id=id;
        this.name=name;
        this.price=price;
    }
}
public class company {

    public static void main(String[] args){
        List<Product>productList=new ArrayList<Product>();

        productList.add(new Product(1,"hp Laptop",27000f));
        productList.add(new Product(2,"acer Laptop",62000f));
        productList.add(new Product(3,"dell Laptop",42000f));
        productList.add(new Product(4,"lenovo Laptop",35000f));
        productList.add(new Product(5,"hppro Laptop",29000f));

        productList.stream()
                .filter(product -> product.price==62000)
                .forEach(product ->
                        System.out.println(product.name));


    }

}
